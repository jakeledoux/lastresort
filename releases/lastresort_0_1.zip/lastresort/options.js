// Jake Ledoux, 2019

'use strict';

var options;
chrome.storage.sync.get("imgreplace", function (details) { options = details["imgreplace"]; ConstructRows();});

function constructOptions(kButtonColors) {
  for (let item of kButtonColors) {
    let button = document.createElement('button');
    button.style.backgroundColor = item;
    button.addEventListener('click', function() {
      chrome.storage.sync.set({color: item}, function() {
        console.log('color is ' + item);
      })
    });
    page.appendChild(button);
  }
}

function addRow(name="", url="", color="#ff0000", idx=-1) {
  let table = document.getElementById('optionsTable');
  let row = table.insertRow(idx);
  row.setAttribute("class", "option", 0);
  let cell1 = row.insertCell(0);
  let cell2 = row.insertCell(1);
  let cell3 = row.insertCell(2);
  let cell4 = row.insertCell(3);

  cell1.innerHTML = '<input type="text" value="' + name + '">';
  cell2.innerHTML = '<input type="url" value="' + url + '">';
  cell3.innerHTML = '<input type="color" value="' + color + '" style="width:25px;">';
  cell4.innerHTML = '<button id="'+row.rowIndex+'">X</button>';

  document.getElementById(row.rowIndex).addEventListener("click", function () { document.getElementById('optionsTable').deleteRow(this.id); });
}

function SaveOptions() {
  var tempOptions = [];
  let table = document.getElementById('optionsTable');
  let rows = table.rows;
  for (var i = 0; i < rows.length; i++) {

    if (rows[i].className == "option") {
      let name = rows[i].cells[0].firstChild.value;
      let url = rows[i].cells[1].firstChild.value;
      let color = rows[i].cells[2].firstChild.value;
      if (name != "" && url != "") {
        tempOptions.push({"name": name, "url": url, "color": color});
      }
    }
  }
  
  chrome.storage.sync.set({"imgreplace": tempOptions}, function(){});
}

function ConstructRows() {
  // Construct rows for options
  try {
    for (var i = 0; i < options.length; i++) {
      addRow(options[i]["name"], options[i]["url"], options[i]["color"]);
    }
  }
  catch (TypeError) {
    addRow();
  }
}

document.getElementById("save-button").addEventListener("click", function() {SaveOptions();});
document.getElementById("add-row").addEventListener("click", function () { addRow(); });
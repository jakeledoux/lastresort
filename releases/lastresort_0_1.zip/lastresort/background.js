// Jake Ledoux, 2019

'use strict';

var filter = {
  url:
    [
      { hostContains: "last.fm" }
    ]
}

chrome.webNavigation.onHistoryStateUpdated.addListener(function (details) {
  chrome.tabs.executeScript(null, { file: "imgreplace.js" });
}, filter);
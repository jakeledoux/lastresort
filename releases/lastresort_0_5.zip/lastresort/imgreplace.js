// Jake Ledoux, 2019

var options;
chrome.storage.sync.get("imgreplace", function (details) {
    options = details["imgreplace"];
    
    for (let i = 0; i < options.length; i++) {
        replace(options[i]["name"], options[i]["url"], options[i]["color"]);
    }
});

function hexToRgb(hex) {
    var result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

function changeImage(imgElement, imgURL) {
    imgElement.src = imgURL;
    imgElement.style.objectFit = "cover";
    imgElement.style.width = "100%";
    imgElement.style.height = "100%";
}

function replace(artistName, imgURL, color)
{
    // The replace call is because Last.fm uses + instead of %20 for URL spaces.
    var artistString = "/music/" + encodeURIComponent(artistName).replace(/%20/g, '+');
    var unencodedArtistString = "/music/" + artistName.replace(/%20/g, '+');
    var artistElements = document.querySelectorAll("a[href='" + artistString + "']");

    // Page header
    if (document.URL.includes("last.fm"+artistString)) {

        // Original artist page
        try {
            let avatars = document.getElementsByClassName("avatar");
            for (let i = 0; i < avatars.length; i++) {
                if (avatars[i].parentElement.href.includes(artistString)) {
                    console.log("ey");
                    avatars[i].src = imgURL;
                }
            }
        }
        catch (TypeError) {}

        // Redesigned Artist Page
        let colorRGB = hexToRgb(color);
        let colorString = `${colorRGB.r}, ${colorRGB.g}, ${colorRGB.b}`;

        let header = document.getElementsByClassName("header-new-background-image")[0];
        header.style.backgroundImage = "url('" + imgURL + "')";
        header.parentElement.style.background = color;

        let gradient = document.getElementsByClassName("header-new-background-overlay")[0];
        let gradientMobile = document.getElementsByClassName("header-new-background-overlay-mobile")[0];

        gradient.style.background = `linear-gradient(0.25turn, rgb(${colorString}), rgba(${colorString}, 0))`;
        gradientMobile.style.background = `linear-gradient(0.25turn, rgb(${colorString}), rgba(${colorString}, 0))`;
        
        // "About this artist"
        let artistImage = document.getElementsByClassName("gallery-preview-image--0");
        if (artistImage.length > 0) {
            artistImage[0].style.width = "100%";
            artistImage[0].style.height = "100%";
            changeImage(artistImage[0].firstElementChild, imgURL);
        }
    }


    // Most images
    for (let i = 0; i < artistElements.length; i++) {
        let artistElement = artistElements[i];

        if (artistElement.parentElement.classList.contains("grid-items-cover-image")) {
            let imgDiv = artistElement.parentElement.getElementsByClassName("grid-items-cover-image-image")[0];
            imgDiv.style.width = "100%";
            imgDiv.style.height = "100%";
            let imgElement = imgDiv.firstElementChild;
            changeImage(imgElement, imgURL);
        }
        else if (artistElement.parentElement.classList.contains("discovery-stat-top-item")) {
            let imgElement = artistElement.parentElement.getElementsByClassName("discovery-stat-top-item-image")[0];
            changeImage(imgElement, imgURL);
        }
        else if (artistElement.parentElement.classList.contains("chartlist-image") || 
            artistElement.parentElement.classList.contains("user-dashboard-catalogue-item-top-item") ||
            artistElement.parentElement.classList.contains("library-header")) {
            let imgElement = artistElement.parentElement.getElementsByClassName("avatar")[0].firstElementChild;
            
            changeImage(imgElement, imgURL);
        }
    }
}
// Jake Ledoux, 2019

'use strict';

var filter = {
  url:
    [
      { hostContains: "last.fm" }
    ]
}
try {
  chrome.webNavigation.onHistoryStateUpdated.addListener(function (details) {
    chrome.tabs.executeScript(null, { file: "imgreplace.js" });
  }, filter);
}
catch {
  console.log("WebNavigation permissions not given.")
}